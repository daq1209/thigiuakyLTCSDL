﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.DAO
{
    public class KhachHangDAO
    {
        private QLBanHangDataContext db = new QLBanHangDataContext();

        public List<QLBanHang.DTO.KhachHang> GetAllKhachHang()
        {
            var query = from kh in db.KhachHangs
                        select new QLBanHang.DTO.KhachHang
                        {
                            MaKH = kh.MaKH,
                            TenKH = kh.TenKH,
                            DienThoai = kh.DienThoai,
                            DiaChi = kh.DiaChi
                        };
            return query.ToList();
        }

        public bool ThemKhachHang(QLBanHang.DTO.KhachHang khDTO)
        {
            try
            {
                var khEntity = new KhachHang // LINQ Entity
                {
                    TenKH = khDTO.TenKH,
                    DienThoai = khDTO.DienThoai,
                    DiaChi = khDTO.DiaChi
                };
                db.KhachHangs.InsertOnSubmit(khEntity);
                db.SubmitChanges();
                return true;
            }
            catch { return false; }
        }

        public bool SuaKhachHang(QLBanHang.DTO.KhachHang khDTO)
        {
            try
            {
                var khEntity = db.KhachHangs.SingleOrDefault(kh => kh.MaKH == khDTO.MaKH);
                if (khEntity != null)
                {
                    khEntity.TenKH = khDTO.TenKH;
                    khEntity.DienThoai = khDTO.DienThoai;
                    khEntity.DiaChi = khDTO.DiaChi;
                    db.SubmitChanges();
                    return true;
                }
                return false;
            }
            catch { return false; }
        }

        public bool XoaKhachHang(int maKH)
        {
            try
            {
                var khEntity = db.KhachHangs.SingleOrDefault(kh => kh.MaKH == maKH);
                if (khEntity != null)
                {
                    db.KhachHangs.DeleteOnSubmit(khEntity);
                    db.SubmitChanges();
                    return true;
                }
                return false;
            }
            catch { return false; }
        }
    }
}