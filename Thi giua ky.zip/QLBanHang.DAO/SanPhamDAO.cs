﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.DAO
{
    public class SanPhamDAO
    {
        private QLBanHangDataContext db = new QLBanHangDataContext();

        // 1. Lấy danh sách
        public List<QLBanHang.DTO.SanPham> GetAllSanPham()
        {
            var query = from sp in db.SanPhams
                        select new QLBanHang.DTO.SanPham
                        {
                            MaSP = sp.MaSP,
                            TenSP = sp.TenSP,
                            // --- SỬA Ở ĐÂY ---
                            // Nếu DonGia là null thì lấy 0
                            DonGia = sp.DonGia ?? 0,
                            // Nếu SoLuong là null thì lấy 0
                            SoLuong = sp.SoLuong ?? 0,
                            // -----------------
                            TrangThai = sp.TrangThai ?? true
                        };
            return query.ToList();
        }

        // 2. Thêm sản phẩm (Giữ nguyên - không lỗi)
        public bool ThemSanPham(QLBanHang.DTO.SanPham spDTO)
        {
            try
            {
                var spEntity = new SanPham
                {
                    TenSP = spDTO.TenSP,
                    DonGia = spDTO.DonGia,
                    SoLuong = spDTO.SoLuong,
                    TrangThai = spDTO.TrangThai
                };

                db.SanPhams.InsertOnSubmit(spEntity);
                db.SubmitChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // 3. Sửa sản phẩm (Giữ nguyên - không lỗi)
        public bool SuaSanPham(QLBanHang.DTO.SanPham spDTO)
        {
            try
            {
                var spEntity = db.SanPhams.SingleOrDefault(sp => sp.MaSP == spDTO.MaSP);
                if (spEntity != null)
                {
                    spEntity.TenSP = spDTO.TenSP;
                    spEntity.DonGia = spDTO.DonGia;
                    spEntity.SoLuong = spDTO.SoLuong;
                    spEntity.TrangThai = spDTO.TrangThai;

                    db.SubmitChanges();
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        // 4. Xóa sản phẩm (Giữ nguyên - không lỗi)
        public bool XoaSanPham(int maSP)
        {
            try
            {
                var spEntity = db.SanPhams.SingleOrDefault(sp => sp.MaSP == maSP);
                if (spEntity != null)
                {
                    db.SanPhams.DeleteOnSubmit(spEntity);
                    db.SubmitChanges();
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        // 5. Tìm kiếm
        public List<QLBanHang.DTO.SanPham> TimKiemSanPham(string keyword)
        {
            var query = from sp in db.SanPhams
                        where sp.TenSP.Contains(keyword)
                        select new QLBanHang.DTO.SanPham
                        {
                            MaSP = sp.MaSP,
                            TenSP = sp.TenSP,
                            // --- SỬA Ở ĐÂY (Giống hàm trên) ---
                            DonGia = sp.DonGia ?? 0,
                            SoLuong = sp.SoLuong ?? 0,
                            // ----------------------------------
                            TrangThai = sp.TrangThai ?? true
                        };
            return query.ToList();
        }
    }
}