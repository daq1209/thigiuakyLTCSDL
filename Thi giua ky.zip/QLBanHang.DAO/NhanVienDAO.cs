﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.DAO
{
    public class NhanVienDAO
    {
        private QLBanHangDataContext db = new QLBanHangDataContext();

        // Lấy danh sách (Trả về List DTO)
        public List<QLBanHang.DTO.NhanVien> GetAllNhanVien()
        {
            var query = from nv in db.NhanViens
                        select new QLBanHang.DTO.NhanVien
                        {
                            MaNV = nv.MaNV,
                            TenNV = nv.TenNV,
                            ChucVu = nv.ChucVu,
                            DienThoai = nv.DienThoai
                        };
            return query.ToList();
        }

        // Thêm nhân viên
        public bool ThemNhanVien(QLBanHang.DTO.NhanVien nvDTO)
        {
            try
            {
                var nvEntity = new NhanVien // Đây là class LINQ
                {
                    TenNV = nvDTO.TenNV,
                    ChucVu = nvDTO.ChucVu,
                    DienThoai = nvDTO.DienThoai
                };
                db.NhanViens.InsertOnSubmit(nvEntity);
                db.SubmitChanges();
                return true;
            }
            catch { return false; }
        }

        // Sửa nhân viên
        public bool SuaNhanVien(QLBanHang.DTO.NhanVien nvDTO)
        {
            try
            {
                var nvEntity = db.NhanViens.SingleOrDefault(nv => nv.MaNV == nvDTO.MaNV);
                if (nvEntity != null)
                {
                    nvEntity.TenNV = nvDTO.TenNV;
                    nvEntity.ChucVu = nvDTO.ChucVu;
                    nvEntity.DienThoai = nvDTO.DienThoai;
                    db.SubmitChanges();
                    return true;
                }
                return false;
            }
            catch { return false; }
        }

        // Xóa nhân viên
        public bool XoaNhanVien(int maNV)
        {
            try
            {
                var nvEntity = db.NhanViens.SingleOrDefault(nv => nv.MaNV == maNV);
                if (nvEntity != null)
                {
                    db.NhanViens.DeleteOnSubmit(nvEntity);
                    db.SubmitChanges();
                    return true;
                }
                return false;
            }
            catch { return false; }
        }
    }
}