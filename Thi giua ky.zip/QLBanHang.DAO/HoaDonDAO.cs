﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.DAO
{
    public class HoaDonDAO
    {
        private QLBanHangDataContext db = new QLBanHangDataContext();

        // Nhận vào DTO.HoaDon và List<DTO.ChiTietHoaDon>
        public bool TaoHoaDon(QLBanHang.DTO.HoaDon hdDTO, List<QLBanHang.DTO.ChiTietHoaDon> listChiTietDTO)
        {
            try
            {
                // 1. Tạo entity Hóa đơn (LINQ)
                var hdEntity = new HoaDon
                {
                    NgayLap = hdDTO.NgayLap,
                    MaNV = hdDTO.MaNV,
                    MaKH = hdDTO.MaKH
                };

                db.HoaDons.InsertOnSubmit(hdEntity);
                db.SubmitChanges(); // Lấy MaHD tự tăng

                // 2. Duyệt danh sách chi tiết
                foreach (var item in listChiTietDTO)
                {
                    var cthdEntity = new ChiTietHoaDon
                    {
                        MaHD = hdEntity.MaHD,
                        MaSP = item.MaSP,
                        SoLuong = item.SoLuong,
                        DonGia = item.DonGia
                    };
                    db.ChiTietHoaDons.InsertOnSubmit(cthdEntity);

                    // Trừ tồn kho (nếu cần)
                    var sp = db.SanPhams.SingleOrDefault(s => s.MaSP == item.MaSP);
                    if (sp != null)
                    {
                        sp.SoLuong -= item.SoLuong;
                    }
                }

                db.SubmitChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}