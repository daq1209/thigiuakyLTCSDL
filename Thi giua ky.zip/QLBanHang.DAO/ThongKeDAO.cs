﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace QLBanHang.DAO
{
    public class ThongKeDAO
    {
        private QLBanHangDataContext db = new QLBanHangDataContext();

        // 1. Danh sách hóa đơn theo ngày
        public object GetHoaDonTheoNgay(DateTime tuNgay, DateTime denNgay)
        {
            var query = from hd in db.HoaDons
                        where hd.NgayLap >= tuNgay && hd.NgayLap <= denNgay
                        select new
                        {
                            MaHD = hd.MaHD,
                            NgayLap = hd.NgayLap,
                            MaNV = hd.MaNV,
                            MaKH = hd.MaKH
                        };
            return query.ToList();
        }

        // 2. Top 3 sản phẩm bán chạy nhất
        public object GetTop3SanPham()
        {
            var query = from ct in db.ChiTietHoaDons
                        group ct by ct.MaSP into g
                        join sp in db.SanPhams on g.Key equals sp.MaSP
                        orderby g.Sum(x => x.SoLuong) descending
                        select new
                        {
                            MaSP = sp.MaSP,
                            TenSP = sp.TenSP,
                            TongSoLuongBan = g.Sum(x => x.SoLuong)
                        };

            return query.Take(3).ToList();
        }

        // 3. Tổng doanh thu theo tháng
        public object GetDoanhThuTheoThang()
        {
            var query = from hd in db.HoaDons
                        join ct in db.ChiTietHoaDons on hd.MaHD equals ct.MaHD
                        group ct by hd.NgayLap.Value.Month into g
                        orderby g.Key
                        select new
                        {
                            Thang = "Tháng " + g.Key,
                            TongDoanhThu = g.Sum(x => x.SoLuong * x.DonGia)
                        };

            return query.ToList();
        }
    }
}