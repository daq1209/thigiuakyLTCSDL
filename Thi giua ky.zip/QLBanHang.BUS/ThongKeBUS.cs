﻿using System;
using QLBanHang.DAO;

namespace QLBanHang.BUS
{
    public class ThongKeBUS
    {
        private ThongKeDAO tkDAO = new ThongKeDAO();

        public object GetHoaDonTheoNgay(DateTime tu, DateTime den)
        {
            return tkDAO.GetHoaDonTheoNgay(tu, den);
        }

        public object GetTop3SanPham()
        {
            return tkDAO.GetTop3SanPham();
        }

        public object GetDoanhThuTheoThang()
        {
            return tkDAO.GetDoanhThuTheoThang();
        }
    }
}