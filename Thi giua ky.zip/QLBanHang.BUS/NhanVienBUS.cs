﻿using System.Collections.Generic;
using NhanVien = QLBanHang.DTO.NhanVien;
using QLBanHang.DAO;

namespace QLBanHang.BUS
{
    public class NhanVienBUS
    {
        private NhanVienDAO nvDAO = new NhanVienDAO();

        public List<NhanVien> GetAllNhanVien()
        {
            return nvDAO.GetAllNhanVien();
        }
    }
}