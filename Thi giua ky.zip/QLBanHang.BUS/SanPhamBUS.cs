﻿using System;
using System.Collections.Generic;
using System.Linq;

using SanPham = QLBanHang.DTO.SanPham;

using QLBanHang.DTO;
using QLBanHang.DAO;

namespace QLBanHang.BUS
{
    public class SanPhamBUS
    {
        private SanPhamDAO spDAO = new SanPhamDAO();

        public List<SanPham> GetAllSanPham()
        {
            return spDAO.GetAllSanPham();
        }

        // Lọc sản phẩm còn hàng
        public List<SanPham> GetSanPhamConHang()
        {
            return spDAO.GetAllSanPham().Where(sp => sp.SoLuong > 0).ToList();
        }

        public List<SanPham> TimKiemSanPham(string tenSP)
        {
            return spDAO.TimKiemSanPham(tenSP);
        }

        public bool ThemSanPham(SanPham sp)
        {
            if (string.IsNullOrEmpty(sp.TenSP)) return false;
            if (sp.DonGia < 0) return false;
            if (sp.SoLuong < 0) return false;

            return spDAO.ThemSanPham(sp);
        }

        public bool SuaSanPham(SanPham sp)
        {
            if (string.IsNullOrEmpty(sp.TenSP)) return false;
            if (sp.DonGia < 0) return false;

            return spDAO.SuaSanPham(sp);
        }

        public bool XoaSanPham(int maSP)
        {
            return spDAO.XoaSanPham(maSP);
        }
    }
}