﻿using System.Collections.Generic;
using KhachHang = QLBanHang.DTO.KhachHang; 
using QLBanHang.DAO;

namespace QLBanHang.BUS
{
    public class KhachHangBUS
    {
        private KhachHangDAO khDAO = new KhachHangDAO();

        public List<KhachHang> GetAllKhachHang()
        {
            return khDAO.GetAllKhachHang();
        }
    }
}