﻿using System.Collections.Generic;
using HoaDon = QLBanHang.DTO.HoaDon; 
using ChiTietHoaDon = QLBanHang.DTO.ChiTietHoaDon;
using QLBanHang.DAO;

namespace QLBanHang.BUS
{
    public class HoaDonBUS
    {
        private HoaDonDAO hdDAO = new HoaDonDAO();

        public bool TaoHoaDon(HoaDon hd, List<ChiTietHoaDon> listChiTiet)
        {
            // Kiểm tra: Giỏ hàng không được trống
            if (listChiTiet == null || listChiTiet.Count == 0)
            {
                return false;
            }
            return hdDAO.TaoHoaDon(hd, listChiTiet);
        }
    }
}