﻿using System;

namespace QLBanHang.DTO
{
    public class ChiTietHoaDon
    {
        public int MaHD { get; set; }
        public int MaSP { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }

        // Thuộc tính phụ để hiển thị tên sản phẩm
        public string TenSP { get; set; }
        public decimal ThanhTien => SoLuong * DonGia; // Thuộc tính tính toán

        public ChiTietHoaDon() { }
    }
}