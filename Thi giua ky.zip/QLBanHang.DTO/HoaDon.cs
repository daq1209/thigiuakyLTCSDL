﻿using System;

namespace QLBanHang.DTO
{
    public class HoaDon
    {
        public int MaHD { get; set; }
        public DateTime NgayLap { get; set; }
        public int MaNV { get; set; }
        public int MaKH { get; set; }

        // Bổ sung thuộc tính phụ để hiển thị tên nếu cần (Option)
        public string TenNV { get; set; }
        public string TenKH { get; set; }

        public HoaDon() { }
    }
}