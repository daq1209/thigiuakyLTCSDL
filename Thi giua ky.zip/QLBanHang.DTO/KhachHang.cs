﻿using System;

namespace QLBanHang.DTO
{
    public class KhachHang
    {
        public int MaKH { get; set; }
        public string TenKH { get; set; }
        public string DienThoai { get; set; }
        public string DiaChi { get; set; }

        public KhachHang() { }

        public KhachHang(int maKH, string tenKH, string dienThoai, string diaChi)
        {
            this.MaKH = maKH;
            this.TenKH = tenKH;
            this.DienThoai = dienThoai;
            this.DiaChi = diaChi;
        }
    }
}