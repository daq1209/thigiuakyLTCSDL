﻿using System;

namespace QLBanHang.DTO
{
    public class NhanVien
    {
        public int MaNV { get; set; }
        public string TenNV { get; set; }
        public string ChucVu { get; set; }
        public string DienThoai { get; set; }

        public NhanVien() { }

        public NhanVien(int maNV, string tenNV, string chucVu, string dienThoai)
        {
            this.MaNV = maNV;
            this.TenNV = tenNV;
            this.ChucVu = chucVu;
            this.DienThoai = dienThoai;
        }
    }
}