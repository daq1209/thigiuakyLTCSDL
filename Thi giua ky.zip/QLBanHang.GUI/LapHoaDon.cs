﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using QLBanHang.BUS;
using QLBanHang.DTO;
namespace QLBanHang.GUI
{
    public partial class frmLapHoaDon : Form
    {
        private SanPhamBUS spBUS = new SanPhamBUS();
        private NhanVienBUS nvBUS = new NhanVienBUS();
        private KhachHangBUS khBUS = new KhachHangBUS();
        private HoaDonBUS hdBUS = new HoaDonBUS();

        private List<ChiTietHoaDon> gioHang = new List<ChiTietHoaDon>();
        public frmLapHoaDon()
        {
            InitializeComponent();
        }

        private void frmLapHoaDon_Load(object sender, EventArgs e)
        {
            // Load Nhân viên
            cboNhanVien.DataSource = nvBUS.GetAllNhanVien();
            cboNhanVien.DisplayMember = "TenNV"; // Hiển thị tên
            cboNhanVien.ValueMember = "MaNV";    // Giá trị ngầm là Mã

            // Load Khách hàng
            cboKhachHang.DataSource = khBUS.GetAllKhachHang();
            cboKhachHang.DisplayMember = "TenKH";
            cboKhachHang.ValueMember = "MaKH";

            // Load Sản phẩm
            cboSanPham.DataSource = spBUS.GetSanPhamConHang(); // Chỉ lấy hàng còn
            cboSanPham.DisplayMember = "TenSP";
            cboSanPham.ValueMember = "MaSP";

            // Cấu hình hiển thị cho GridView Giỏ hàng (nếu cần)
            dgvGioHang.AutoGenerateColumns = false;
        }

        private void cboSanPham_SelectedIndexChanged(object sender, EventArgs e)
        {
            SanPham sp = cboSanPham.SelectedItem as SanPham;
            if (sp != null)
            {
                txtDonGia.Text = sp.DonGia.ToString();
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                // Lấy thông tin sản phẩm đang chọn
                SanPham spDangChon = cboSanPham.SelectedItem as SanPham;
                int soLuongMua = int.Parse(txtSoLuong.Text);

                if (spDangChon == null) return;
                if (soLuongMua <= 0)
                {
                    MessageBox.Show("Số lượng phải lớn hơn 0");
                    return;
                }

                // Kiểm tra tồn kho (Optional: Logic nâng cao)
                if (soLuongMua > spDangChon.SoLuong)
                {
                    MessageBox.Show("Kho chỉ còn " + spDangChon.SoLuong + " sản phẩm!");
                    return;
                }

                // Kiểm tra xem sản phẩm đã có trong giỏ chưa
                var itemTrongGio = gioHang.SingleOrDefault(x => x.MaSP == spDangChon.MaSP);

                if (itemTrongGio != null)
                {
                    // Nếu có rồi -> Cộng dồn số lượng
                    itemTrongGio.SoLuong += soLuongMua;
                }
                else
                {
                    // Chưa có -> Tạo mới chi tiết
                    ChiTietHoaDon ct = new ChiTietHoaDon
                    {
                        MaSP = spDangChon.MaSP,
                        TenSP = spDangChon.TenSP, // Gán tên để hiển thị ra Grid
                        DonGia = spDangChon.DonGia,
                        SoLuong = soLuongMua
                    };
                    gioHang.Add(ct);
                }

                // Cập nhật lại giao diện
                LoadGioHangLenLuoi();
                TinhTongTien();
            }
            catch (Exception)
            {
                MessageBox.Show("Số lượng nhập không hợp lệ!");
            }
        }

        private void LoadGioHangLenLuoi()
        {
            dgvGioHang.DataSource = null;
            dgvGioHang.DataSource = gioHang;

            // Ẩn cột không cần thiết (Mã HD chưa có)
            if (dgvGioHang.Columns["MaHD"] != null) dgvGioHang.Columns["MaHD"].Visible = false;
        }

        
        private void TinhTongTien()
        {
            // LINQ: Sum(Số lượng * Đơn giá)
            decimal tongTien = gioHang.Sum(ct => ct.SoLuong * ct.DonGia);

            lblTongTien.Text = tongTien.ToString("#,##0") + " VNĐ"; // Format tiền tệ
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (gioHang.Count == 0)
            {
                MessageBox.Show("Giỏ hàng đang trống!");
                return;
            }

            try
            {
                // Bước 1: Tạo đối tượng Hóa Đơn
                HoaDon hd = new HoaDon
                {
                    NgayLap = DateTime.Now,
                    MaNV = (int)cboNhanVien.SelectedValue,
                    MaKH = (int)cboKhachHang.SelectedValue
                };

                // Bước 2: Gọi BUS để lưu cả Hóa đơn và List Chi tiết
                if (hdBUS.TaoHoaDon(hd, gioHang))
                {
                    MessageBox.Show("Thanh toán thành công!");

                    // Reset lại form để bán tiếp
                    gioHang.Clear();
                    LoadGioHangLenLuoi();
                    lblTongTien.Text = "0 VNĐ";
                }
                else
                {
                    MessageBox.Show("Thanh toán thất bại!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}
