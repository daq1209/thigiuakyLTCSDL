﻿using System;
using System.Windows.Forms;
using QLBanHang.BUS;

namespace QLBanHang.GUI
{
    public partial class frmThongKe : Form
    {
        private ThongKeBUS tkBUS = new ThongKeBUS();

        public frmThongKe()
        {
            InitializeComponent();
        }

        private void frmThongKe_Load(object sender, EventArgs e)
        {
            // Load mặc định Top 3 và Doanh thu ngay khi mở form
            LoadTop3();
            LoadDoanhThu();

            // Set ngày mặc định cho dtp (Từ đầu tháng đến nay)
        }

        // Tab 1: Xem hóa đơn theo ngày
        private void btnXemHD_Click(object sender, EventArgs e)
        {
            DateTime tu = dtpTuNgay.Value;
            DateTime den = dtpDenNgay.Value;
            dgvHoaDon.DataSource = tkBUS.GetHoaDonTheoNgay(tu, den);
        }

        // Tab 2: Top 3
        private void LoadTop3()
        {
            dgvTop3.DataSource = tkBUS.GetTop3SanPham();
            // Format cột nếu cần
            if (dgvTop3.Columns["TongSoLuongBan"] != null)
                dgvTop3.Columns["TongSoLuongBan"].HeaderText = "Số Lượng Bán";
        }

        // Tab 3: Doanh thu
        private void LoadDoanhThu()
        {
            dgvHoaDon.DataSource = tkBUS.GetDoanhThuTheoThang();
            if (dgvHoaDon.Columns["TongDoanhThu"] != null)
                dgvHoaDon.Columns["TongDoanhThu"].DefaultCellStyle.Format = "#,##0 VNĐ";
        }
    }
}