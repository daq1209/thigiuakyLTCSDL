﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLBanHang.BUS;
using QLBanHang.DTO;
namespace QLBanHang.GUI
{
    public partial class frmSanPham : Form
    {
        private SanPhamBUS spBUS = new SanPhamBUS();
        private List<SanPham> _danhSachGoc = new List<SanPham>();
        public frmSanPham()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadDanhSachSanPham();
        }
        private void LoadDanhSachSanPham()
        {
            dgvSanPham.DataSource = spBUS.GetAllSanPham();

            // Đặt tên tiêu đề cột cho đẹp (Tùy chọn)
            if (dgvSanPham.Columns["MaSP"] != null) dgvSanPham.Columns["MaSP"].HeaderText = "Mã SP";
            if (dgvSanPham.Columns["TenSP"] != null) dgvSanPham.Columns["TenSP"].HeaderText = "Tên Sản Phẩm";
            if (dgvSanPham.Columns["DonGia"] != null) dgvSanPham.Columns["DonGia"].HeaderText = "Đơn Giá";
            if (dgvSanPham.Columns["SoLuong"] != null) dgvSanPham.Columns["SoLuong"].HeaderText = "Số Lượng";
        }
        private void dgvSanPham_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvSanPham.Rows[e.RowIndex];
                txtMaSP.Text = row.Cells["MaSP"].Value.ToString();
                txtTenSP.Text = row.Cells["TenSP"].Value.ToString();
                txtDonGia.Text = row.Cells["DonGia"].Value.ToString();
                txtSoLuong.Text = row.Cells["SoLuong"].Value.ToString();
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.Trim().ToLower(); // Chuyển về chữ thường để tìm không phân biệt hoa thường

            var ketQua = _danhSachGoc
                         .Where(sp => sp.TenSP.ToLower().Contains(keyword))
                         .ToList();
            dgvSanPham.DataSource = ketQua; 
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtMaSP.Text))
                {
                    MessageBox.Show("Vui lòng chọn sản phẩm để sửa!");
                    return;
                }

                SanPham sp = new SanPham
                {
                    MaSP = int.Parse(txtMaSP.Text),
                    TenSP = txtTenSP.Text,
                    DonGia = decimal.Parse(txtDonGia.Text),
                    SoLuong = int.Parse(txtSoLuong.Text),
                    TrangThai = true
                };

                if (spBUS.SuaSanPham(sp))
                {
                    MessageBox.Show("Sửa thành công!");
                    LoadDanhSachSanPham();
                }
                else
                {
                    MessageBox.Show("Sửa thất bại!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Dữ liệu không hợp lệ.");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaSP.Text)) return;

            if (MessageBox.Show("Bạn có chắc muốn xóa?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int maSP = int.Parse(txtMaSP.Text);
                if (spBUS.XoaSanPham(maSP))
                {
                    MessageBox.Show("Xóa thành công!");
                    LoadDanhSachSanPham();

                    // Xóa trắng các ô nhập
                    txtMaSP.Text = ""; txtTenSP.Text = "";
                    txtDonGia.Text = ""; txtSoLuong.Text = "";
                }
                else
                {
                    MessageBox.Show("Xóa thất bại!");
                }
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text;
            dgvSanPham.DataSource = spBUS.TimKiemSanPham(keyword);
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LoadDanhSachSanPham();
            txtTimKiem.Text = "";
        }

        private void chkConHang_CheckedChanged(object sender, EventArgs e)
        {
            if (chkConHang.Checked)
            {
                dgvSanPham.DataSource = spBUS.GetSanPhamConHang();
            }
            else
            {
                LoadDanhSachSanPham();
            }
        }
    }
}
