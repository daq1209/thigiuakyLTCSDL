﻿using System;
using System.Windows.Forms;

namespace QLBanHang.GUI
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        // Sự kiện nút Quản lý Sản phẩm
        private void btnQuanLySP_Click(object sender, EventArgs e)
        {
            frmSanPham f = new frmSanPham();
            this.Hide(); // Ẩn form chính đi cho gọn
            f.ShowDialog(); // Hiển thị form con
            this.Show(); // Khi tắt form con thì hiện lại form chính
        }

        // Sự kiện nút Lập Hóa Đơn
        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            frmLapHoaDon f = new frmLapHoaDon();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        // Sự kiện nút Thống Kê (Nếu bạn đã làm form này)
        private void btnThongKe_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem bạn đã tạo frmThongKe chưa, nếu chưa thì comment dòng dưới lại
            frmThongKe f = new frmThongKe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        // Sự kiện nút Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}